package com.sinamdemoapp.service;

import com.sinamdemoapp.entity.FileUpload;

import java.util.Optional;

public interface FileUploadService {

    void saveFile(FileUpload fileUpload);
    Iterable<FileUpload> getAllFiles();
    void deleteFileById(int id);
    Optional<FileUpload> getFileById(int id);
}
