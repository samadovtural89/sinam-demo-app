package com.sinamdemoapp.service;

import com.sinamdemoapp.entity.UserRole;

public interface UserRoleService {

    void createUserRole(UserRole userRole);
}
