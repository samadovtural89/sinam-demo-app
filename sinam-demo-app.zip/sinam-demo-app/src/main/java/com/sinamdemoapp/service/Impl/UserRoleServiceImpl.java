package com.sinamdemoapp.service.Impl;

import com.sinamdemoapp.dao.UserRoleDao;
import com.sinamdemoapp.entity.UserRole;
import com.sinamdemoapp.service.UserRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserRoleServiceImpl implements UserRoleService {

    @Autowired
    private UserRoleDao userRoleDao;

    @Override
    public void createUserRole(UserRole userRole) {
        userRoleDao.createUserRole(userRole);
    }
}
