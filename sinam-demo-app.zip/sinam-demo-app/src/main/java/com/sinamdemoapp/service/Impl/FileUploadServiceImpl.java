package com.sinamdemoapp.service.Impl;

import com.sinamdemoapp.dao.FileUploadDao;
import com.sinamdemoapp.entity.FileUpload;
import com.sinamdemoapp.service.FileUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional
public class FileUploadServiceImpl implements FileUploadService {

    @Autowired
    private FileUploadDao fileUploadDao;

    @Override
    public void saveFile(FileUpload fileUpload) {
        fileUploadDao.saveFile(fileUpload);
    }

    @Override
    public Iterable<FileUpload> getAllFiles() {
        return fileUploadDao.getAllFiles();
    }

    @Override
    public void deleteFileById(int id) {
        fileUploadDao.deleteFileById(id);
    }

    @Override
    public Optional<FileUpload> getFileById(int id) {
        return fileUploadDao.getFileById(id);
    }
}
