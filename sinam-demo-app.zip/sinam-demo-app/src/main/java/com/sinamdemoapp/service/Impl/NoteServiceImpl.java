package com.sinamdemoapp.service.Impl;

import com.sinamdemoapp.dao.NoteDao;
import com.sinamdemoapp.entity.Note;
import com.sinamdemoapp.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class NoteServiceImpl implements NoteService {

    @Autowired
    private NoteDao noteDao;

    @Override
    public void createNote(Note note) {
        noteDao.createNote(note);
    }

    @Override
    public Iterable<Note> findByNoteUserId(int noteUserId) {
        return noteDao.findByNoteUserId(noteUserId);
    }

    @Override
    public Optional<Note> getNoteById(int id) {
        return noteDao.getNoteById(id);
    }

    @Override
    public void deleteNoteById(int id) {
        noteDao.deleteNoteById(id);
    }

    @Override
    public void updateNote(String noteHeader, String noteContent, int noteId) {
        noteDao.updateNote(noteHeader,noteContent, noteId);
    }


    // REST

    @Override
    public List<Note> getNotesByUserIdForRest(int userId) {
        return noteDao.getNotesByUserIdForRest(userId);
    }

    @Override
    public Optional<Note> getNoteByNoteIdForRest(int noteId) {
        return noteDao.getNoteByNoteIdForRest(noteId);
    }


}
