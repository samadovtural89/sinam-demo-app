package com.sinamdemoapp.service.Impl;

import com.sinamdemoapp.dao.UserDao;
import com.sinamdemoapp.entity.User;
import com.sinamdemoapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;


    // UI

    @Override
    public Optional<User> getUserByUsername(String username) {
        return userDao.getUserByUsername(username);
    }

    @Override
    public void createUser(User user) {
        userDao.createUser(user);
    }

    @Override
    public void updateUser(String username, String name, String surname, int id) {
        userDao.updateUser(username, name, surname, id);
    }

    @Override
    public void deleteUserById(int id) {
        userDao.deleteUserById(id);
    }

    @Override
    public Optional<User> getUserById(int id) {
        return userDao.getUserById(id);
    }

    @Override
    public List<User> findAllUsers() {
        return userDao.findAllUsers();
    }


    // REST

    @Override
    public List<User> getAllUsersForRest() {
        return userDao.getAllUsersForRest();
    }

    @Override
    public Optional<User> getUserByIdForRest(int userId) {
        return userDao.getUserByIdForRest(userId);
    }
}
