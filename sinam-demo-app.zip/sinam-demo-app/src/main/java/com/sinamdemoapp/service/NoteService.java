package com.sinamdemoapp.service;

import com.sinamdemoapp.entity.Note;

import java.util.List;
import java.util.Optional;

public interface NoteService {

    void createNote(Note note);
    Iterable<Note> findByNoteUserId(int noteUserId);
    Optional<Note> getNoteById(int id);
    void deleteNoteById(int id);
    void updateNote(String noteHeader, String noteContent, int noteId);

    // REST

    List<Note> getNotesByUserIdForRest(int userId);
    Optional<Note> getNoteByNoteIdForRest(int noteId);
}
