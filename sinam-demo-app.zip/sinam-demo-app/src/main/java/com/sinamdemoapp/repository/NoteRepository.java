package com.sinamdemoapp.repository;

import com.sinamdemoapp.entity.Note;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface NoteRepository extends JpaRepository<Note, Integer> {

    // UI

    Iterable<Note> findByNoteUserId(int noteUserId);

    @Modifying
    @Query(value = "update note set header = :header, note = :noteContent where note_id = :noteId", nativeQuery = true)
    void updateNote(@Param("header") String header, @Param("noteContent") String noteContent, @Param("noteId") Integer noteId);



    // REST

    @Query("SELECT n.noteId, n.noteHeader, n.noteContent FROM Note n WHERE n.noteUserId = :noteUserId")
    List<Note> getNotesByUserIdForRest(@Param("noteUserId") Integer noteUserId);

    @Query("SELECT n.noteId, n.noteHeader, n.noteContent FROM Note n WHERE n.noteId = :noteId")
    Optional<Note> getNoteByNoteIdForRest(@Param("noteId") Integer noteId);

}
