package com.sinamdemoapp.repository;

import com.sinamdemoapp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    // UI

    @Modifying
    @Query(value = "delete from user where user_id = :userId", nativeQuery = true)
    void deleteUser(@Param("userId") Integer userId);

    @Modifying
    @Query(value = "update user set username = :username, name = :name, surname = :surname where user_id = :userId", nativeQuery = true)
    void updateUser(@Param("username") String username, @Param("name") String name, @Param("surname") String surname, @Param("userId") Integer userId);

    @Query("SELECT u FROM User u WHERE u.userId <> (SELECT ur.user_id FROM UserRole ur WHERE ur.role_id = 1)")
    List<User> getAllUsers();

    Optional<User> findByUsername(String username);


    // REST

    @Query("SELECT u.userId, u.name, u.surname, u.username FROM User u WHERE u.userId <> (SELECT ur.user_id FROM UserRole ur WHERE ur.role_id = 1)")
    List<User> getAllUsersForRest();

    @Query("SELECT u.userId, u.name, u.surname, u.username FROM User u WHERE u.userId = :userId")
    Optional<User> getUserByIdForRest(@Param("userId") Integer userId);
}
