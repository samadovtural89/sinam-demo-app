package com.sinamdemoapp.dao.impl;

import com.sinamdemoapp.dao.UserDao;
import com.sinamdemoapp.entity.User;
import com.sinamdemoapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class UserDaoImpl implements UserDao {

    @Autowired
    private UserRepository userRepository;


    // UI

    @Override
    public Optional<User> getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public void createUser(User user) {
        userRepository.save(user);
    }

    @Override
    public void updateUser(String username, String name, String surname, int id) {
        userRepository.updateUser(username, name, surname, id);
    }

    @Override
    public void deleteUserById(int id) {
        userRepository.deleteUser(id);
    }

    @Override
    public Optional<User> getUserById(int id) {
        return userRepository.findById(id);
    }

    @Override
    public List<User> findAllUsers() {
        return userRepository.getAllUsers();
    }


    // REST

    @Override
    public List<User> getAllUsersForRest() {
        return userRepository.getAllUsersForRest();
    }

    @Override
    public Optional<User> getUserByIdForRest(int userId) {
        return userRepository.getUserByIdForRest(userId);
    }
}
