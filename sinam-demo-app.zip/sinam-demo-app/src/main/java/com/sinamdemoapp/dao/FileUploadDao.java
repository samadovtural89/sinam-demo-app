package com.sinamdemoapp.dao;

import com.sinamdemoapp.entity.FileUpload;

import java.util.Optional;

public interface FileUploadDao {

    void saveFile(FileUpload fileUpload);
    Iterable<FileUpload> getAllFiles();
    void deleteFileById(int id);
    Optional<FileUpload> getFileById(int id);
}
