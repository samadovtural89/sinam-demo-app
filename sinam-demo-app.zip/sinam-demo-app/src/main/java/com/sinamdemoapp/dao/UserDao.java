package com.sinamdemoapp.dao;

import com.sinamdemoapp.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserDao {

    // UI
    List<User> findAllUsers();
    void deleteUserById(int id);
    void createUser(User user);
    void updateUser(String username, String name, String surname, int id);
    Optional<User> getUserById(int id);
    Optional<User> getUserByUsername(String username);

    // REST
    List<User> getAllUsersForRest();
    Optional<User> getUserByIdForRest(int userId);
}
