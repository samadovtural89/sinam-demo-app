package com.sinamdemoapp.dao.impl;

import com.sinamdemoapp.dao.FileUploadDao;
import com.sinamdemoapp.entity.FileUpload;
import com.sinamdemoapp.repository.FileUploadRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class FileUploadDaoImpl implements FileUploadDao {

    @Autowired
    private FileUploadRepository fileUploadRepository;

    @Override
    public void saveFile(FileUpload fileUpload) {
        fileUploadRepository.save(fileUpload);
    }

    @Override
    public Iterable<FileUpload> getAllFiles() {
        return fileUploadRepository.findAll();
    }

    @Override
    public void deleteFileById(int id) {
        fileUploadRepository.deleteById(id);
    }

    @Override
    public Optional<FileUpload> getFileById(int id) {
        return fileUploadRepository.findById(id);
    }
}
