package com.sinamdemoapp.dao.impl;

import com.sinamdemoapp.dao.NoteDao;
import com.sinamdemoapp.entity.Note;
import com.sinamdemoapp.repository.NoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class NoteDaoImpl implements NoteDao {

    @Autowired
    private NoteRepository noteRepository;

    @Override
    public void createNote(Note note) {
        noteRepository.save(note);
    }

    @Override
    public Iterable<Note> findByNoteUserId(int noteUserId) {
        return noteRepository.findByNoteUserId(noteUserId);
    }

    @Override
    public Optional<Note> getNoteById(int id) {
        return noteRepository.findById(id);
    }

    @Override
    public void deleteNoteById(int id) {
        noteRepository.deleteById(id);
    }

    @Override
    public void updateNote(String noteHeader, String noteContent, int noteId) {
        noteRepository.updateNote(noteHeader, noteContent, noteId);
    }


    // REST

    @Override
    public List<Note> getNotesByUserIdForRest(int userId) {
        return noteRepository.getNotesByUserIdForRest(userId);
    }

    @Override
    public Optional<Note> getNoteByNoteIdForRest(int noteId) {
        return noteRepository.getNoteByNoteIdForRest(noteId);
    }


}
