package com.sinamdemoapp.dao;

import com.sinamdemoapp.entity.UserRole;

public interface UserRoleDao {

    void createUserRole(UserRole userRole);
}
