package com.sinamdemoapp.dao.impl;

import com.sinamdemoapp.dao.UserRoleDao;
import com.sinamdemoapp.entity.UserRole;
import com.sinamdemoapp.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserRoleDaoImpl implements UserRoleDao {

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Override
    public void createUserRole(UserRole userRole) {
        userRoleRepository.save(userRole);
    }
}
