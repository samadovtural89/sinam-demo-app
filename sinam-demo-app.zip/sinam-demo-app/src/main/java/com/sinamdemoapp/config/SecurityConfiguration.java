package com.sinamdemoapp.config;

import com.sinamdemoapp.service.Impl.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@EnableWebSecurity
@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(customUserDetailsService)
                .passwordEncoder(getPasswordEncoder());
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable();
        http.authorizeRequests().antMatchers("/sinam-demo-app/user/**").access("hasRole('ADMIN')");
        http.authorizeRequests().antMatchers("/sinam-demo-app/users/**").access("hasRole('ADMIN')");
        http.authorizeRequests().antMatchers("/sinam-demo-app/file**").access("hasRole('ADMIN')");
        http.authorizeRequests().antMatchers("/sinam-demo-app/home/**").access("hasAnyRole('USER','ADMIN')");
        http.authorizeRequests().antMatchers("/sinam-demo-app/notes/**").access("hasAnyRole('USER','ADMIN')");
        http.authorizeRequests().antMatchers("/sinam-demo-app/note/**").access("hasRole('USER')");
        http.authorizeRequests().antMatchers("/","/home").access("hasAnyRole('USER','ADMIN')");


        //REST
        /*http.authorizeRequests().antMatchers("/sinam-demo-app/api/user/**").access("hasRole('ADMIN')");
        http.authorizeRequests().antMatchers("/sinam-demo-app/api/users/**").access("hasRole('ADMIN')");
        http.authorizeRequests().antMatchers("/sinam-demo-app/api/notes/**").access("hasAnyRole('USER','ADMIN')");
        http.authorizeRequests().antMatchers("/sinam-demo-app/api/note/**").access("hasRole('USER')");*/

        http.authorizeRequests().and().formLogin().loginPage("/sinam-demo-app/login").defaultSuccessUrl("/");
        http.authorizeRequests().and().exceptionHandling().accessDeniedPage("/sinam-demo-app/403");
        http.authorizeRequests().and().logout().logoutUrl("/sinam-demo-app/logout").logoutSuccessUrl("/sinam-demo-app/login").permitAll();
    }

    public BCryptPasswordEncoder getPasswordEncoder(){
        return new BCryptPasswordEncoder();
    }
}
