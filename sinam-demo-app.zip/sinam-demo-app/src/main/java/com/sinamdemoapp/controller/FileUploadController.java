package com.sinamdemoapp.controller;

import com.sinamdemoapp.entity.FileUpload;
import com.sinamdemoapp.entity.Role;
import com.sinamdemoapp.entity.User;
import com.sinamdemoapp.service.FileUploadService;
import com.sinamdemoapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping(value = "/sinam-demo-app")
public class FileUploadController {

    // this path must be customized
    private static String UPLOADED_FOLDER_PATH = "C:/Intellij IDEA Ultimate Workspaces/sinam/sinam-demo-app/src/main/webapp/resources/images/";
    private String fileName = null;

    @Autowired
    private FileUploadService fileUploadService;

    @Autowired
    private UserService userService;

    @GetMapping(value = "/fileupload")
    public String accessDenied(Model model){
        model.addAttribute("checkURL", "FileUpload");
        return "index";
    }

    @PostMapping("/fileuploadprocess")
    public String singleFileUpload(@RequestParam ("file") MultipartFile file , Model model){

        if (file.isEmpty()) {
            model.addAttribute("messageError", "Please select a file to upload");
            model.addAttribute("checkURL", "FileUploadResult");
            return "index";
        }

        try {
            fileName = file.getOriginalFilename();
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER_PATH + fileName);
            Files.write(path, bytes);

            FileUpload fileUpload = new FileUpload();
            fileUpload.setFileName(fileName);
            fileUploadService.saveFile(fileUpload);

            model.addAttribute("messageSuccess", "You successfully uploaded '" + fileName + "'");
            model.addAttribute("checkURL", "FileUploadResult");
        } catch (Exception e){
            System.out.println(e);
        }

        return "index";
    }


    @GetMapping(value = "/files")
    public String files(Model model, Principal principal, HttpSession session){
        if(session.getAttribute("roleName") == null || session.getAttribute("roleName") == ""){
            findUserRole(model, principal, session);
        }
        Iterable<FileUpload> fileUploads = fileUploadService.getAllFiles();
        List<FileUpload> fileList = new ArrayList<>();
        for (FileUpload fileUpload : fileUploads) {
            fileList.add(fileUpload);
        }
        model.addAttribute("fileList", fileList);
        model.addAttribute("checkURL", "files");
        return "index";
    }

    @GetMapping(value = "/file/delete/{id}")
    public String deleteFileById(@PathVariable("id") int id, Model model,Principal principal, HttpSession session){
        if(session.getAttribute("roleName") == null || session.getAttribute("roleName") == ""){
            findUserRole(model, principal, session);
        }

        Optional<FileUpload> optionalFileUpload = fileUploadService.getFileById(id);
        String fileName = optionalFileUpload.get().getFileName();
        File file=new File(UPLOADED_FOLDER_PATH + fileName);
        if(file.exists()){
            if(file.delete()){
                fileUploadService.deleteFileById(id);
                System.out.println("File deleted successfully");
            }else{
                System.out.println("Fail to delete file");
            }
        }
        return "redirect:/sinam-demo-app/files";
    }

    public void findUserRole(Model model, Principal principal, HttpSession session){
        UserController.findUserRoleNew(principal, session, userService);
    }

}
