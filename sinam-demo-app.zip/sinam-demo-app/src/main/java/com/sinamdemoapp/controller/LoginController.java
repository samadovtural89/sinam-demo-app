package com.sinamdemoapp.controller;

import com.sinamdemoapp.entity.Role;
import com.sinamdemoapp.entity.User;
import com.sinamdemoapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.security.Principal;
import java.util.Optional;

@Controller
@RequestMapping(value = {"/","/sinam-demo-app"})
public class LoginController implements ErrorController {

    @Autowired
    private UserService userService;

    //Custom login sehifesine yonlenmek ucun mutleqdir
    @GetMapping(value = "/login")
    public String loginGet() {
        return "login";
    }

    @GetMapping(value = "/")
    public String main(Model model, Principal principal, HttpSession session) {
        findUserRole(model, principal, session);
        return "index";
    }

    @GetMapping(value = "/home")
    public String index(Model model, Principal principal, HttpSession session) {
        findUserRole(model, principal, session);
        return "index";
    }

    public void findUserRole(Model model, Principal principal, HttpSession session){
        Optional<User> user = userService.getUserByUsername(principal.getName());
        String roleName = null;
        for (Role role : user.get().getRoles()) {
            roleName = role.getRole();
        }
        session.setAttribute("roleName",roleName);
        session.setAttribute("loggedUserId",user.get().getUserId());
        model.addAttribute("loggedUserUsername",user.get().getUsername());
        model.addAttribute("loggedUserName",user.get().getName());
        model.addAttribute("loggedUserSurname",user.get().getSurname());
        model.addAttribute("checkURL", "welcome-view");
    }

    @Override
    public String getErrorPath() {
        return "/error";
    }

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);

        if (status != null) {
            Integer statusCode = Integer.valueOf(status.toString());

            if(statusCode == HttpStatus.NOT_FOUND.value()) {
                return "404";
            }
            else if(statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
                return "500";
            }
        }
        return "index";
    }
}
