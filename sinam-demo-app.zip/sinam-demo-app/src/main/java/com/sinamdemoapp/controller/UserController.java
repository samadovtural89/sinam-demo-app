package com.sinamdemoapp.controller;

import com.sinamdemoapp.entity.Role;
import com.sinamdemoapp.entity.User;
import com.sinamdemoapp.entity.UserRole;
import com.sinamdemoapp.service.UserRoleService;
import com.sinamdemoapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping(value = "/sinam-demo-app")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRoleService userRoleService;

    @GetMapping(value = "/403")
    public String accessDenied(Model model, Principal principal, HttpSession session){
        if(session.getAttribute("roleName") == null || session.getAttribute("roleName") == ""){
            findUserRole(model, principal, session);
        }
        model.addAttribute("checkURL", "403");
        return "index";
    }

    @GetMapping(value = "/users")
    public String users(Model model, Principal principal, HttpSession session){
        if(session.getAttribute("roleName") == null || session.getAttribute("roleName") == ""){
            findUserRole(model, principal, session);
        }
        List<User> userList = userService.findAllUsers();
        model.addAttribute("userList", userList);
        model.addAttribute("checkURL", "users");
        return "index";
    }

    @GetMapping(value = "/user/new")
    public String newUser(@ModelAttribute("user") User user, Model model, BindingResult result, Principal principal, HttpSession session){
        if(session.getAttribute("roleName") == null || session.getAttribute("roleName") == ""){
            findUserRole(model, principal, session);
        }
        model.addAttribute("checkURL", "User");
        return "index";
    }

    @GetMapping(value = "/user/delete/{id}")
    public String deleteUserById(@PathVariable("id") int id, Model model){
        userService.deleteUserById(id);
        return "redirect:/sinam-demo-app/users";
    }

    @PostMapping(value = "/user/save")
    public String saveUser(@ModelAttribute("user") User user, BindingResult result, Model model){
        if(user.getUserId() == 0){
            user.setPassword(encodedPassword(user.getPassword()));
            userService.createUser(user);

            UserRole userRole = new UserRole();
            userRole.setUser_id(user.getUserId());
            userRole.setRole_id(2);
            userRoleService.createUserRole(userRole);
        } else {
            userService.updateUser(user.getUsername(), user.getName(), user.getSurname(), user.getUserId());
        }
        return "redirect:/sinam-demo-app/users";
    }

    @GetMapping(value = "/user/update/{id}")
    public String showUserById(@PathVariable("id") int id, Model model,@ModelAttribute("user") User user, BindingResult result, Principal principal, HttpSession session){
        if(session.getAttribute("roleName") == null || session.getAttribute("roleName") == ""){
            findUserRole(model, principal, session);
        }
        Optional<User> optionalUser = userService.getUserById(id);
        model.addAttribute("userId", optionalUser.get().getUserId());
        model.addAttribute("userName", optionalUser.get().getName());
        model.addAttribute("userSurname", optionalUser.get().getSurname());
        model.addAttribute("userUsername", optionalUser.get().getUsername());
        model.addAttribute("checkURL", "User");
        return "index";
    }

    public String encodedPassword(String password){
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String encodedPassword = encoder.encode(password);
        return encodedPassword;
    }

    public void findUserRole(Model model, Principal principal, HttpSession session){
        findUserRoleNew(principal, session, userService);
    }

    static void findUserRoleNew(Principal principal, HttpSession session, UserService userService) {
        Optional<User> user = userService.getUserByUsername(principal.getName());
        String roleName = null;
        for (Role role : user.get().getRoles()) {
            roleName = role.getRole();
        }
        session.setAttribute("roleName",roleName);
        session.setAttribute("loggedUserId",user.get().getUserId());
    }

}
