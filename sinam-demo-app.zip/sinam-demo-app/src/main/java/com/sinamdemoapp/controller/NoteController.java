package com.sinamdemoapp.controller;

import com.sinamdemoapp.entity.Note;
import com.sinamdemoapp.entity.Role;
import com.sinamdemoapp.entity.User;
import com.sinamdemoapp.service.NoteService;
import com.sinamdemoapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import sun.rmi.runtime.Log;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping(value = "/sinam-demo-app")
public class NoteController {

    @Autowired
    private NoteService noteService;

    @Autowired
    private UserService userService;

    @GetMapping(value = "/notes/{id}")
    public String notes(@PathVariable("id") int id, Model model, Principal principal, HttpSession session){
        if(session.getAttribute("roleName") == null || session.getAttribute("roleName") == ""){
            findUserRole(model, principal, session);
        }
        Iterable<Note> notes = noteService.findByNoteUserId(id);
        List<Note> noteList = new ArrayList<>();
        for (Note note : notes) {
            noteList.add(note);
        }
        model.addAttribute("noteList", noteList);
        model.addAttribute("checkURL", "notes");
        return "index";
    }

    @GetMapping(value = "/note/new")
    public String newNote(@ModelAttribute("note") Note note, Model model, BindingResult result, Principal principal, HttpSession session){
        if(session.getAttribute("roleName") == null || session.getAttribute("roleName") == ""){
            findUserRole(model, principal, session);
        }
        model.addAttribute("checkURL", "Note");
        return "index";
    }

    @PostMapping(value = "/note/save/{userId}")
    public String saveNote(@ModelAttribute("note") Note note,@PathVariable("userId") int userId, Model model, BindingResult result, HttpServletRequest request){
        String param = request.getParameter("updatedNoteId");
        if(param == "" || param == null){
            noteService.createNote(note);
        } else {
            int noteId = Integer.parseInt(param);
            noteService.updateNote(note.getNoteHeader(), note.getNoteContent(), noteId);
        }
        return "redirect:/sinam-demo-app/notes/" + userId;
    }

    @GetMapping(value = "/note/delete/{userId}/{noteId}")
    public String deleteNoteById(@PathVariable("userId") int userId, @PathVariable("noteId") int noteId, Model model){
        noteService.deleteNoteById(noteId);
        return "redirect:/sinam-demo-app/notes/" + userId;
    }

    @GetMapping(value = "/note/update/{id}")
    public String showNoteById(@ModelAttribute("note") Note note, @PathVariable("id") int id, Model model, BindingResult result){
        Optional<Note> optionalNote = noteService.getNoteById(id);
        model.addAttribute("updateNoteId", optionalNote.get().getNoteId());
        model.addAttribute("updateNoteHeader", optionalNote.get().getNoteHeader());
        model.addAttribute("updateNoteContent", optionalNote.get().getNoteContent());
        model.addAttribute("checkURL", "Note");
        return "index";
    }

    public void findUserRole(Model model, Principal principal, HttpSession session){
        UserController.findUserRoleNew(principal, session, userService);
    }

}
