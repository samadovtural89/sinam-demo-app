package com.sinamdemoapp.controller;

import com.sinamdemoapp.entity.User;
import com.sinamdemoapp.entity.UserRole;
import com.sinamdemoapp.service.UserRoleService;
import com.sinamdemoapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/sinam-demo-app/api")
public class UserRestController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRoleService userRoleService;

    @GetMapping(value = "/users")
    public List<User> users(){
        return userService.getAllUsersForRest();
    }

    @DeleteMapping(value = "/user/delete/{id}")
    public String deleteUserById(@PathVariable("id") int id){
        userService.deleteUserById(id);
        return "User deleted successfully";
    }

    @PostMapping(value = "/user/save")
    public Optional<User> createUser(@RequestBody User user){
        // Create user
        user.setPassword(encodedPassword(user.getPassword()));
        userService.createUser(user);

        // Create user role
        UserRole userRole = new UserRole();
        userRole.setUser_id(user.getUserId());
        userRole.setRole_id(2);
        userRoleService.createUserRole(userRole);

        // Return created user
        return userService.getUserByIdForRest(user.getUserId());
    }

    @PutMapping(value = "/user/update/{id}")
    public Optional<User> updateUser(@RequestBody User user, @PathVariable("id") int id){
        userService.updateUser(user.getUsername(), user.getName(), user.getSurname(), id);
        return userService.getUserByIdForRest(id);
    }

    public String encodedPassword(String password){
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String encodedPassword = encoder.encode(password);
        return encodedPassword;
    }

}
