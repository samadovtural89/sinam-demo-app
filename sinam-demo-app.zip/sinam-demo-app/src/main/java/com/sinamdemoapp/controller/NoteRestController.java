package com.sinamdemoapp.controller;

import com.sinamdemoapp.entity.Note;
import com.sinamdemoapp.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/sinam-demo-app/api")
public class NoteRestController {

    @Autowired
    private NoteService noteService;

    @GetMapping(value = "/notes/{id}")
    public List<Note> notes(@PathVariable("id") int id){
        return noteService.getNotesByUserIdForRest(id);
    }

    @PostMapping(value = "/note/save")
    public Optional<Note> createNote(@RequestBody Note note){
        // Create note
        noteService.createNote(note);

        // Return created note
        return noteService.getNoteByNoteIdForRest(note.getNoteId());
    }

    @DeleteMapping(value = "/note/delete/{id}")
    public String deleteNoteById(@PathVariable("id") int id){
        noteService.deleteNoteById(id);
        return "Note deleted successfully";
    }

    @PutMapping(value = "/note/update/{id}")
    public Optional<Note> updateNote(@RequestBody Note note, @PathVariable("id") int id){
        noteService.updateNote(note.getNoteHeader(), note.getNoteContent(), id);
        return noteService.getNoteByNoteIdForRest(id);
    }
}
