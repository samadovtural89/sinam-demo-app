package com.sinamdemoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SinamDemoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SinamDemoAppApplication.class, args);
	}
}
